This directory contains tests for the --nimblePath feature.

